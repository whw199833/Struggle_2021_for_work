#include <mpi.h>
#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <time.h>
#include <iostream>
#include <sstream>
#include "local_domain.h"

using namespace std;

//------------------------------------------------Global Variables---------------------------------------------------------------

// id: the number number of the current process
// p: the total number of processes that have been assigned
int id, p;

// define global i, j values
// this is also size for the whole domains
// users can define and change size here
int g_imax = 100, g_jmax = 100;

// the following four integers are rows and cols for local regions after best decomposition
int l_imax_normal, l_jmax_normal, l_imax_last, l_jmax_last;
//to store rows and cols for each processors
int* prow_all = new int[p];
int* pcol_all = new int[p];

// find the best decomposition based on processors
// total number of local regions = procs_rows * procs_cols
int procs_rows, procs_cols;

// define three local domains: old, current and new
// create 3 grids to store old, current and new data
//local_domain* ghost_old_grid = new local_domain(prow_all[id], pcol_all[id]);
//local_domain* ghost_current_grid = new local_domain(prow_all[id], pcol_all[id]);
//local_domain* ghost_new_grid = new local_domain(prow_all[id], pcol_all[id]);

// the time and time step are the same for local and global region:
//double t_max = 30.0;
double t_max = 3.0;
double t, t_out = 0.0, dt_out = 0.04, dt;
double y_max = 10.0, x_max = 10.0, dx, dy;
double c = 1;

//------------------------------------------------setup_domain function-----------------------------------------------------------

// implement grid decomposition based on total number of processors (p)
// to devide domain into rectangles that are as close to square as possible
// which makes code more efficient
void setup_domain()
{
	// set the initial minimum gap as g_imax
	// or it can be set to g_jmax, it will not influence results because we will 
	// loop over p value later to find best decomposition
	int min_gap = g_imax;

	// loop over the processors
	// to update minimum gap (also this means the best grid decoomposition is found)
	if (p == 1)
	{
		procs_rows = 1;
		procs_cols = 1;
	}
	else
	{
		for (int i = 1; i < p; i++)
		{
			if (p % i == 0)
			{
				int gap = abs(g_jmax / (p / i) - g_imax / i);

				// compare current gap value with min_gap
				if (gap <= min_gap)
				{
					// update min_gap value
					min_gap = gap;
					procs_rows = i;
					procs_cols = p / i;
				}
			}
		}
	}
	
	if (id == 0)
		cout << "Divide " << p << " processors into " << procs_rows << " by " << procs_cols << " grid" << endl;


	// if g_imax cannot be divided by procs_rows with 0 remainder or g_jmax cannot be divided by procs_cols with 0 remainder,
	// then right-hand-side and bottom local domains have different cols and rows compared with "normal" dimains:
	l_imax_normal = floor((double)g_imax / (double)procs_rows); // round down to nearest integer
	l_jmax_normal = floor((double)g_jmax / (double)procs_cols); // round down to nearest integer
	l_imax_last = g_imax - l_imax_normal * (procs_rows - 1); // rows for bottom processors
	l_jmax_last = g_jmax - l_jmax_normal * (procs_cols - 1); // cols for right-hand-side processors


	if (id == 0)
	{
		cout << "The general value of grid's rows is: " << l_imax_normal << endl;
		cout << "The rows for the bottom processors is: " << l_imax_last << endl;
		cout << "The general value of grid's cols is: " << l_jmax_normal << endl;
		cout << "The cols for the right-hand-side processors is: " << l_jmax_last << endl;
		cout << endl;
	}
	// assign cols and rows to each processors based on index numbers
	// invert 2d to 1d array: id = i * cols + j

	for (int i = 0; i < procs_rows; i++)
	{
		for (int j = 0; j < procs_cols; j++)
		{
			// assign value grid's rows for each processor
			if (i != procs_rows - 1)
				prow_all[i * procs_cols + j] = l_imax_normal;
			else
				prow_all[i * procs_cols + j] = l_imax_last;

			// assign value grid's cols for each processor
			if (j != procs_cols - 1)
				pcol_all[i * procs_cols + j] = l_jmax_normal;
			else
				pcol_all[i * procs_cols + j] = l_jmax_last;

			// check local domain size for different processor
			//if (id == 0)
			//	cout << "The current processor " << i * procs_cols + j << " has " << prow_all[i * procs_cols + j] << " rows, " << pcol_all[i * procs_cols + j] << " cols." << endl;
		}
	}
}

// using a vector to store neighour's id, for periodic one it has 4 neighbours all the time
vector<int> neighbor_ids(4);
// function to find four neighbours for periodic one
void find_neighbours_periodic(int id)
{
	// change id number to index number
	// id = i * cols + j
	int id_row = id / procs_cols;
	int id_column = id % procs_cols;
	// count numbers of neighbours
	int cnt = 0;
	// find and check whether top, bottom, left and right neighbouring processors are existed
	for (int i = -1; i <= 1; i++)
	{
		for (int j = -1; j <= 1; j++)
		{
			if (i == 0 && j == 0) // centre square, id is itself
				continue;

			if (i == -1 && j == -1) // left-top corner
				continue;

			if (i == -1 && j == 1) // right-top corner
				continue;

			if (i == 1 && j == -1) // left-bottom corner
				continue;

			if (i == 1 && j == 1) // right-bottom corner
				continue;

			// we can add procs_rows and proces_cols to temp_i and temp_j to avoid out of bounds situations
			// and use remainder to indicate locations for neighbours
			int temp_i = (i + id_row + procs_rows) % procs_rows;
			int temp_j = (j + id_column + procs_cols) % procs_cols;
			int id_neighbour = temp_i * procs_cols + temp_j;
			// cout << "id: " << id << " neighbour: " << id_neighbour << endl;
			// add it into neighbours vector
			neighbor_ids[cnt] = id_neighbour;
			cnt++;
		}
	}
	// check
	// cout << "id: " << id << " neighbour: " << neighbor_ids[0] << neighbor_ids[1] << neighbor_ids[2] << neighbor_ids[3]<< endl;
}

// once we found neighbours of current processors, we need to know which edges need to be
// sent by neighbours and which edges need to be received by current processors


void comm_with_neighbours(int id, local_domain& ghost_old_grid, local_domain & ghost_current_grid, local_domain& ghost_new_grid, double dt, double dy, double dx, double c)
{
	// find neighbours for specific id
	find_neighbours_periodic(id);

	// each processor will do receive and send with others (general case:)
	// send and receive processes with 8 numbers to specifies locations:
	// |   |   |  4 |   |   |
	// |   |   |  0 |   |   |
	// | 5 | 1 | id | 2 | 6 |
	// |   |   |  3 |   |   |
	// |   |   |  7 |   |   |

	// do communications below:
	MPI_Request* request = new MPI_Request[8];
	int cnt = 0;
	for (int i = 0; i < 4; i++)
	{
		MPI_Isend(MPI_BOTTOM, 1, ghost_current_grid.datatype_send_position[i], neighbor_ids[i], i, MPI_COMM_WORLD, &request[cnt]);
		cnt++;
		//MPI_Irecv(MPI_BOTTOM, 1, ghost_current_grid.datatype_recv_position[i], neighbor_ids[i], i, MPI_COMM_WORLD, &request[i]);
	}
	
	for (int i = 0; i < 4; i++)
	{
		//MPI_Isend(MPI_BOTTOM, 1, ghost_current_grid.datatype_position[i], neighbor_ids[i], i, MPI_COMM_WORLD, &request[i]);
		MPI_Irecv(MPI_BOTTOM, 1, ghost_current_grid.datatype_recv_position[i], neighbor_ids[i], i, MPI_COMM_WORLD, &request[cnt]);
		cnt++;
	}
	
	MPI_Waitall(8, request, MPI_STATUS_IGNORE);
	ghost_current_grid.do_wave_equation(&ghost_old_grid, &ghost_new_grid, dt, dy, dx, c);
}


int main(int argc, char* argv[])
{
	// set up MPI communication
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &id);
	MPI_Comm_size(MPI_COMM_WORLD, &p);

	// devide domain based on total number of processors
	setup_domain();
	// determine sizes for local domains
	//size_for_grid();

	//id2index(id, id_row, id_column);
	//find_neighbours_periodic(id);

	// create 3 grids to store old, current and new data
	local_domain* ghost_old_grid = new local_domain(prow_all[id], pcol_all[id]);
	local_domain* ghost_current_grid = new local_domain(prow_all[id], pcol_all[id]);
	local_domain* ghost_new_grid = new local_domain(prow_all[id], pcol_all[id]);
	
	// initialize three grids with zeros and create all datatypes
	ghost_old_grid->initial_with_zeros();
	ghost_old_grid->create_all_datatypes();
	ghost_current_grid->initial_with_zeros();
	ghost_current_grid->create_all_datatypes();
	ghost_new_grid->initial_with_zeros();
	ghost_new_grid->create_all_datatypes();

	// initialize current grid with a right_bottom point
	if (id == 0)
	{
		for(int i = 1; i <= prow_all[0]+1; i++)
			for (int j = 1; j <= pcol_all[0]+1; j++)
				ghost_current_grid->array_data[i][j] = 1;
		//ghost_current_grid->array_data[prow_all[0] + 1][pcol_all[0] + 1] = 1;
	}

	dx = x_max / ((double)g_imax - 1);
	dy = y_max / ((double)g_imax - 1);

	t = 0.0;
	// strict time step constraints: dt << min(dx, dy) / c, so can use prefector 0.1 or 0.2 to limit time step,
	// choosing 0.1 here to make results more accurate
	dt = 0.1 * min(dx, dy) / c;

	int out_cnt = 0, it = 0;

	ghost_current_grid->grid_to_file(out_cnt, id);
	out_cnt++;
	t_out += dt_out;

	// do iterations:
	while (t<t_max)
	{
		comm_with_neighbours(id, *ghost_old_grid, *ghost_current_grid, *ghost_new_grid, dt, dy, dx, c);
		if (t_out <= t)
		{
			cout << "output: " << out_cnt << "\tt: " << t << "\titeration: " << it << endl;
			ghost_current_grid->grid_to_file(out_cnt, id);
			out_cnt++;
			t_out += dt_out;
		}
		t += dt;
		it++;
	}

	// free all mpi datatypes
	ghost_old_grid->free_all_datatypes();
	ghost_current_grid->free_all_datatypes();
	ghost_new_grid->free_all_datatypes();

	MPI_Finalize();
}