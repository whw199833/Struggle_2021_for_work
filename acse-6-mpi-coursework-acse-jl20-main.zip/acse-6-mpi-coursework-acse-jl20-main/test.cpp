#include <mpi.h>
#include <iostream>
#include <vector>

using namespace std;

//------------------------------------------------Global Variables--------------------------------------------------------------

// id: the number number of the current process
// p: the total number of processes that have been assigned
int id, p;

// define global i, j values
// this is also size for the whole domains
// users can define and change size here
int g_imax = 100, g_jmax = 200;

// the following four integers are rows and cols for local regions after best decomposition
int l_imax_normal, l_jmax_normal, l_imax_last, l_jmax_last;

// find the best decomposition based on processors
// total number of local regions = procs_rows * procs_cols
int procs_rows, procs_cols;

// using a vector to store neighour's id
vector<int> neighbor_ids;

//------------------------------------------------setup_domain function-----------------------------------------------------------

// implement grid decomposition based on total number of processors (p)
// to devide domain into rectangles that are as close to square as possible
// which makes code more efficient
void setup_domain()
{
	// set the initial minimum gap as g_imax
	// or it can be set to g_jmax, it will not influence results because we will 
	// loop over p value later to find best decomposition
	int min_gap = g_imax;

	// loop over the processors
	// to update minimum gap (also this means the best grid decoomposition is found)
	for (int i = 1; i < p; i++)
	{
		if (p % i == 0)
		{
			int gap = abs(g_jmax / (p / i) - g_imax / i);

			// compare current gap value with min_gap
			if (gap < min_gap)
			{
				// update min_gap value
				min_gap = gap;
				procs_rows = i;
				procs_cols = p / i;
			}
		}
	}

	if (id == 0)
		cout << "Divide " << p << " processors into " << procs_rows << " by " << procs_cols << " grid" << endl;
}

//------------------------------------------------size_for_grid function----------------------------------------------------------

// once we done the grid decomposition based on total number of processors
// let's determine the size for local domain
void size_for_grid()
{
	// determine rows and cols for local domain:
	if ((g_imax % procs_rows == 0) && (g_jmax % procs_cols == 0))
	{
		// if g_imax can be divided by procs_rows with 0 remainder and g_jmax can be divided by procs_cols with 0 remainder,
		// then each local domain has the same size:
		l_imax_normal = g_imax / procs_rows;
		l_jmax_normal = g_jmax / procs_cols;
		l_imax_last = l_imax_normal;
		l_jmax_last = l_jmax_normal;
	}
	else
	{
		// if g_imax cannot be divided by procs_rows with 0 remainder or g_jmax cannot be divided by procs_cols with 0 remainder,
		// then right-hand-side and bottom local domains have different cols and rows compared with "normal" dimains:
		l_imax_normal = floor((double)g_imax / (double)procs_rows); // round down to nearest integer
		l_jmax_normal = floor((double)g_jmax / (double)procs_cols); // round down to nearest integer
		l_imax_last = g_imax - l_imax_normal * (procs_rows - 1); // rows for bottom processors
		l_jmax_last = g_jmax - l_jmax_normal * (procs_cols - 1); // cols for right-hand-side processors
	}

	if (id == 0)
	{
		cout << "The general value of grid's rows is: " << l_imax_normal << endl;
		cout << "The rows for the bottom processors is: " << l_imax_last << endl;
		cout << "The general value of grid's cols is: " << l_jmax_normal << endl;
		cout << "The cols for the right-hand-side processors is: " << l_jmax_last << endl;
		cout << endl;
	}
	// assign cols and rows to each processors based on index numbers
	// invert 2d to 1d array: id = i * cols + j
	/*
	for (int i = 0; i < procs_rows; i++)
	{
		for (int j = 0; j < procs_cols; j++)
		{
			// assign value grid's rows for each processor
			if (i != procs_rows - 1)
				grid_rows[i * procs_cols + j] = l_imax_normal;
			else
				grid_rows[i * procs_cols + j] = l_imax_last;

			// assign value grid's cols for each processor
			if (j != procs_cols - 1)
				grid_cols[i * procs_cols + j] = l_jmax_normal;
			else
				grid_cols[i * procs_cols + j] = l_jmax_last;

			if (id == 0)
				cout << "The current processor " << i * procs_cols + j << " has " << grid_rows[i * procs_cols + j] << " rows, " << grid_cols[i * procs_cols + j] << " cols." << endl;
		}
	}
	*/
}

// the find_neighbours function is to find neighbouring processors (top, bottom, left and right processors)
void find_neighbours(int id)
{
	// change id number to index number
	// id = i * cols + j
	int id_row = id / procs_cols;
	int id_column = id % procs_cols;

	// find and check whether top, bottom, left and right neighbouring processors are existed
	for (int i = -1; i <= 1; i++)
	{
		for (int j = -1; j <= 1; j++)
		{
			if (i == 0 && j == 0) // centre square, id is itself
				continue;

			if (i + id_row < 0 || i + id_row >= procs_rows) // out of bounds in the i-direction
				continue;

			if (j + id_column < 0 || j + id_column >= procs_cols) // out of bounds in the j-direction
				continue;

			if (i == -1 && j == -1) // left-top corner
				continue;

			if (i == -1 && j == 1) // right-top corner
				continue;

			if (i == 1 && j == -1) // left-bottom corner
				continue;

			if (i == 1 && j == 1) // right-bottom corner
				continue;

			int id_neighbour = (i + id_row) * procs_cols + (j + id_column);

			//cout << id_neighbour << endl;

			neighbor_ids.push_back(id_neighbour);
		}
	}
}

int main(int argc, char* argv[])
{
	// set up MPI communication
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &id);
	MPI_Comm_size(MPI_COMM_WORLD, &p);
	// devide domain based on total number of processors
	setup_domain();
	// determine sizes for local domains
	size_for_grid();

	find_neighbours(3);

	MPI_Finalize();
}