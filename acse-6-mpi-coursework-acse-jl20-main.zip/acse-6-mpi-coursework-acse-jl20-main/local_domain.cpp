#include "local_domain.h"

using namespace std;


// construct
local_domain::local_domain(int m, int n)
{
	ghost_row = m + 2;
	ghost_col = n + 2;
	// create 2d array include ghost cells:
	this->array_data = new double* [ghost_row];
	for (int j = 0; j < ghost_row; j++)
	{
		this->array_data[j] = new double[ghost_col];	
	}
}

// destruct
local_domain::~local_domain()
{
	for (int i = 0; i < ghost_row; i++)
		delete[] this->array_data[i];
	delete[] this->array_data;
}

// we can use row to define which row to be received or send
// position is used to looking for MPI_Datatype in a vector
void local_domain::create_row_type(int row, MPI_Datatype *position)
{
	int block_length;
	MPI_Datatype typeval;
	MPI_Aint address, temp;

	block_length = ghost_col - 2;
	typeval = MPI_DOUBLE;

	MPI_Get_address(&this->array_data[row][1], &temp);
	address = temp;

	// create the structure for the MPI_datatype
	MPI_Type_create_struct(1, &block_length, &address, &typeval, position);
	// once we've created MPI_datatype, we need to commit it before it be used in any communications
	MPI_Type_commit(position);
}

// we can use col to define which column to be received or send
// position is used to looking for MPI_Datatype in a vector
void local_domain::create_col_type(int col, MPI_Datatype* position)
{
	vector<int> block_lengths;
	vector<MPI_Datatype> typelist;
	vector<MPI_Aint> addresses;
	MPI_Aint temp_add;

	for (int i = 1; i <= ghost_row - 2; i++)
	{
		block_lengths.push_back(1);
		typelist.push_back(MPI_DOUBLE);
		MPI_Get_address(&this->array_data[i][col], &temp_add);
		addresses.push_back(temp_add);
	}

	// create the structure for the MPI_datatype
	MPI_Type_create_struct(block_lengths.size(), &block_lengths[0], &addresses[0], &typelist[0], position);
	// once we've created MPI_datatype, we need to commit it before it be used in any communications
	MPI_Type_commit(position);
}

void local_domain::create_all_datatypes()
{
	// send top row (from second row)
	create_row_type(1, &datatype_send_position[0]);
	// receive bottom row from a neighbour and add it to the first row
	create_row_type(0, &datatype_recv_position[0]);
	// send bottom row (from second last row)
	create_row_type(ghost_row - 2, &datatype_send_position[3]);
	// receive top row from a neighbour and add it to the last row
	create_row_type(ghost_row - 1, &datatype_recv_position[3]);
	// send left col (from second col)
	create_col_type(1, &datatype_send_position[1]);
	// receive right col from a neighbour and add it to the first col
	create_col_type(0, &datatype_recv_position[1]);
	// send right col (from second last col)
	create_col_type(ghost_col - 2, &datatype_send_position[2]);
	// receive left col from a neighbour and add it to the last col
	create_col_type(ghost_col - 1, &datatype_recv_position[2]);
}

void local_domain::free_all_datatypes()
{
	for (int i = 0; i < 4; i++)
	{
		MPI_Type_free(&datatype_send_position[i]);
		MPI_Type_free(&datatype_recv_position[i]);
	}
}

void local_domain::initial_with_zeros()
{
	for (int i = 0; i < ghost_row; i++)
		for (int j = 0; j < ghost_col; j++)
			this->array_data[i][j] = 0;
}

void local_domain::do_wave_equation(local_domain *old_grid, local_domain* new_grid, double dt, double dy, double dx, double c)
{
	// no edge here (different calculation for main fuild and boundaries)
	// if we are looking into the main fuild we will do below wave calculations:
	for (int i = 1; i <= ghost_row - 2; i++)
		for (int j = 1; j <= ghost_col - 2; j++)
			new_grid->array_data[i][j] = pow(dt * c, 2.0) * ((this->array_data[i + 1][j] - 2.0 * this->array_data[i][j] + this->array_data[i - 1][j]) / pow(dx, 2.0) + (this->array_data[i][j + 1] - 2.0 * this->array_data[i][j] + this->array_data[i][j - 1]) / pow(dy, 2.0)) + 2.0 * this->array_data[i][j] - old_grid->array_data[i][j];

	// a vector swap isn't copying data (trying to avoid copying data because it is very slow)
	// do two swaps below (current -> old, new -> current):
	for (int i = 0; i <= ghost_row - 1; i++)
		for (int j = 0; j <= ghost_col - 1; j++)
		{
			old_grid->array_data[i][j] = this->array_data[i][j];
			this->array_data[i][j] = new_grid->array_data[i][j];
		}
}


// write out data to file
void local_domain::grid_to_file(int out, int id)
{
	stringstream fname;
	fstream f1;
	fname << "_id_" << id << "_" << out << ".txt";
	f1.open(fname.str().c_str(), ios_base::out);
	for (int i = 1; i < ghost_row; i++)
	{
		for (int j = 1; j < ghost_col; j++)
			f1 << this->array_data[i][j] << "\t";
		f1 << endl;
	}
	f1.close();
}