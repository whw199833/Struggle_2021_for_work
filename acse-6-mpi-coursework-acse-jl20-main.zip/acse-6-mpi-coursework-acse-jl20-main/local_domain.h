#pragma once
#include <mpi.h>
#include <iostream>
#include <cstdlib>
#include <time.h>
#include <vector>
#include <sstream>
#include <fstream>
#include <cmath>

using namespace std;

class local_domain
{
public:
	// construct local domain based on rows and cols for each processor
	// local size = m * n
	local_domain(int m, int n);

	// destructor
	virtual ~local_domain();

	void create_row_type(int row, MPI_Datatype* position);
	void create_col_type(int col, MPI_Datatype* position);
	void create_all_datatypes();
	void free_all_datatypes();
	void initial_with_zeros();
	void do_wave_equation(local_domain* old_grid, local_domain* new_grid, double dt, double dy, double dx, double c);
	void grid_to_file(int out, int id);


	double** array_data;
	// first four data to send and last four data to receive
	MPI_Datatype datatype_send_position[4];
	MPI_Datatype datatype_recv_position[4];

	int ghost_row, ghost_col;
	
};